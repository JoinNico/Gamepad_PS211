## powered by astra UI.

# [Releases](https://github.com/dcfsswindy/oled-ui-astra/releases)

# [Wiki](https://github.com/dcfsswindy/oled-ui-astra/wiki)

# [Video](https://www.bilibili.com/video/BV16x421S7qc)