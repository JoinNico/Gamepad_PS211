//
// Created by Fir on 2024/3/21 021
//

#pragma once
#ifndef ASTRA_CORE_SRC_ASTRA_ASTRA_LOGO_H_
#define ASTRA_CORE_SRC_ASTRA_ASTRA_LOGO_H_

#include "../hal/hal.h"

namespace astra {

void drawLogo(uint16_t _time);

}

#endif //ASTRA_CORE_SRC_ASTRA_ASTRA_LOGO_H_
