//
// Created by Fir on 2024/2/1.
//

#pragma once
#ifndef ASTRA_CORE_SRC_ASTRA_APP_I_H_
#define ASTRA_CORE_SRC_ASTRA_APP_I_H_


namespace astra {
class App_i {
public:
  //virtual void
};
}
#endif //ASTRA_CORE_SRC_ASTRA_APP_I_H_
