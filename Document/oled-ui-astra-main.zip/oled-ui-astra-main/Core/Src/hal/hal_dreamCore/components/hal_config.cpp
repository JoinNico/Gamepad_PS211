//
// Created by Fir on 2024/2/12.
//
#include "../hal_dreamCore.h"

void HALDreamCore::_updateConfig() {

}