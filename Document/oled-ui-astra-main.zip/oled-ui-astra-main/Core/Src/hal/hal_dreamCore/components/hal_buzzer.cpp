//
// Created by Fir on 2024/2/11.
//
#include "../hal_dreamCore.h"

void HALDreamCore::_buzzer_init() {

}

void HALDreamCore::_beep(float _freq) {

}

void HALDreamCore::_beepStop() {

}

void HALDreamCore::_setBeepVol(unsigned char _vol) {

}