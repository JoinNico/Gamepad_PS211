#ifndef _TIM_OCTIGR_H
#define _TIM_OCTIGR_H

#include "stm32f10x.h"

void TIM_OCTigrConfig(void);

#endif
