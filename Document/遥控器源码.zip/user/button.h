#ifndef _BUTTON_H
#define _BUTTON_H

#include "stm32f10x.h"



void BUTTON_Config(void);

#endif
